 #include <iostream>
#include<fstream>
#include <string>
#include <crafter.h>
/* Collapse namespaces */
using namespace std;
using namespace Crafter;
/* Function for handling a packet */
void PacketHandler(Packet* sniff_packet, void* user)
{
        /* sniff_packet -> pointer to the packet captured */
        /* user -> void pointer to the data supplied by the user */
        /* Check if there is a payload */
        RawLayer* raw_payload = sniff_packet->GetLayer<RawLayer>();
        if(raw_payload)
	{
                cout << "----------------" << endl;
                /* Summarize some data */
                TCP* tcp_layer = sniff_packet->GetLayer<TCP>();
                cout << "[#] TCP packet from source port: " << tcp_layer->GetSrcPort() << endl;
                cout << "[#] With Payload: " << endl;
                /* for getting payload as a string */
                string payload = raw_payload->GetStringPayload();
                cout << payload << endl;
		ofstream outfile;
   		outfile.open("file.txt", ios::app);
		outfile<<payload;

	}
		ifstream file("file.txt");    
		int wcount = 0;
		int count = 0;
		int count1 = 0;
		
		string token;
		string word("GET");
		string word1("HTTP/1.1");
		string word2("304");
		
		while (file>>token)
   			if (word == token)
    				wcount++;
			else if(word1 == token)
				count++;
			else if(word2 == token)
				count1++;
			
		ofstream outfile1;
		outfile1.open("file1.txt");
		outfile1<<"Occurence of request: "<<wcount<<"\nOccurence of response:" <<count<<"\n Status code 304: "<<count1;

		file.close(); //closing file		
}
int main()
{
        /* Set the interface */
        string iface = "p4p1";
          /* First, create a sniffer
         - 1st argument: Filter expression (tcpdump syntax)
         - 2nd argument: Interface
          - 3rd argument: A function that will be executed when a packet
         captured satisfies the filter expression (the default behavior is to print the packets to STDOUT).
         */
        Sniffer sniff("tcp and port 3128",iface,PacketHandler);   
 /* Now, start the capture (one packets) */
        sniff.Capture(-1);
        return 0;
}
