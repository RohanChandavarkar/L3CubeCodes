import os
ip=raw_input("Enter IP Address of the system")
os.system("ssh root@"+ip+" \"yum install dhcp\" ")
