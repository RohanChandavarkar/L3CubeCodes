import os
from netaddr import *
import sys
import socket
import fcntl
import struct

def get_ip_address(ifname):
	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	return socket.inet_ntoa(fcntl.ioctl(s.fileno(),0x8915,struct.pack('256s', ifname[:15]))[20:24])


MyIP = get_ip_address('p4p1')
print "Host machine's IP address: "+MyIP
ip = IPNetwork(MyIP+"/28")
print "Subnet Mask is : "+str(ip.netmask)
print "Host Mask is : "+str(ip.hostmask)

print "subnets formed are:"
i=-1
subnetarray = []
while i<256:
	print str(i+1)+"-"+str(i+16)
	subnetarray.append(i+16)
	i=i+16 


#print subnetarray

getip = raw_input("Enter the IP address to ping: ")

checking = int(getip[10:])
#print checking

i = 0;
subnetnumber = 0
while(True):
	if(checking <= subnetarray[i]):
		subnetnumber = i
		break
	i+=1

#print subnetnumber

checking = int(MyIP[10:])
j=0
mysubnetnum = 0
while(True):
	if(checking <= subnetarray[j]):
		mysubnetnum = j
		break
	j+=1

#print mysubnetnum


if(subnetnumber==mysubnetnum):
	print "Pinging in the same subnet"
	os.system("ping -c 5 "+getip)

else:
	print "Pinging in the other subnet"
	os.system("ping -c 5 "+getip)
