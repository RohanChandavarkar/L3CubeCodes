import java.io.*;
import java.util.*;
import java.lang.*;
import java.net.*;

public class client{
static Socket socket;
public static void main(String args[]) throws Exception
{
 try
        {
	
        String host = "localhost";
        int port = 80;
        InetAddress address = InetAddress.getByName(host);
        socket = new Socket(address, port);
	PrintWriter w =new PrintWriter(socket.getOutputStream(), true);
	BufferedReader b =
        new BufferedReader(
            new InputStreamReader(socket.getInputStream()));
    BufferedReader a =
        new BufferedReader(
         new InputStreamReader(System.in));
	//String s=b.readLine();
	System.out.println("Enter html file:\n");
	String s1=null;
s1=a.readLine();
w.println("GET /"+s1);
//int i=10;
while(true)
{
s1=b.readLine();
if(s1.equals("quit"))
break;
System.out.println(s1);
//i--;
}
}
  catch(Exception exception)
        {
            exception.printStackTrace();
        }
        finally
        {
            //Closing the socket
            try
            {
                socket.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
}
 
}
}
