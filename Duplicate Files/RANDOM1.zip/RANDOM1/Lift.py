import Adafruit_BBIO.GPIO as GPIO
import time

ffl = "P8_11"
sfl = "P8_13"
tfl = "P8_15"

ffb = "P8_12"
sfb = "P8_14"
tfb = "P8_16"

GPIO.setup("P8_11",GPIO.OUT)
GPIO.setup("P8_13",GPIO.OUT)
GPIO.setup("P8_15",GPIO.OUT)

GPIO.setup("P8_12",GPIO.IN)
GPIO.setup("P8_14",GPIO.IN)
GPIO.setup("P8_16",GPIO.IN)

def getCurrent(current):
	if current==1:
		return ffl
	if current==2:
		return sfl
	if current==3:
		return tfl	
	
current = 1

while(true):
	GPIO.output(getCurrent(current),GPIO.HIGH)
	
	input1 = GPIO.input(ffb)
	input2 = GPIO.input(sfb)
	input3 = GPIO.input(tfb)
	
	if(input1):
		GPIO.output(getCurrent(current),GPIO.LOW)
		if(current==3):
			GPIO.output(sfl,GPIO.HIGH)
			time.sleep(1)
			GPIO.output(sfl,GPIO.LOW)
		current = 1
		print "WE ARE ON FLOOR 1"
		
	if(input2):
		GPIO.output(getCurrent(current),GPIO.LOW)
		current = 2
		print "WE ARE ON FLOOR 2"
		
	if(input3):
		GPIO.output(getCurrent(current),GPIO.LOW)
		if(current==1):
			GPIO.output(sfl,GPIO.HIGH)
			time.sleep(1)
			GPIO.output(sfl,GPIO.LOW)
		current = 3
		print "WE ARE ON FLOOR 3"