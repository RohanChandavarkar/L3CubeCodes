#include "iostream"
#include <stdio.h>
#include <omp.h>
#include <math.h>

using namespace std;

int main()
{
	int s,ele,n,l,r,blk,tid,flag=0,index;
	int i,j,k;
	cout<<"\nEnter no of elements = ";
	cin>>s;
	int arr[s],sep[s];
	cout<<"\nEnter the elements = \n";
	for(i=0;i<s;i++)
	{
		cin>>arr[i];
	}
	for(j=0;j<s-1;j++)
	{
		for(k=0;k<s-j-1;k++)
		{
			if(arr[k]>arr[k+1])
			{
				int swap = arr[k];
				arr[k] = arr[k+1];
				arr[k+1] = swap;
			}
		}
	}
	cout<<"\nThe sorted array is = \n";
	for(i=0;i<s;i++)
	{
		cout<<arr[i]<<"\t";
	}
	cout<<"\nEnter the element to be searched = ";
	cin>>ele;
	cout<<"\nEnter the value of n for n-ary search = ";
	cin>>n;
	l=0;
	r=s-1;
	if(ele>=arr[l] && ele<=arr[r])
	{
		while(l!=r)
		{
			cout<<"\nl = "<<l<<" r = "<<r<<" s = "<<s;
			if(s<=n)
			{
				#pragma omp parallel for num_threads(s)
				for(i=0;i<s;i++)
				{
					sep[i] = l+i;
					tid = omp_get_thread_num();
					printf("\nThread %d allocated sep[%d]=%d",tid,i,sep[i]);
				}
			}
			else
			{
				sep[0] = l;
				blk = ceil((float)s/(float)n);
				#pragma omp parallel for num_threads(n-1)
				for(i=1;i<=n-1;i++)
				{
					sep[i] = l+blk*i-1;
					tid = omp_get_thread_num();
					printf("\nThread %d allocated sep[%d]=%d",tid,i,sep[i]);
				}
				sep[n] = r;
			}
			for(i=0;i<=n;i++)
			{
				if(ele==arr[sep[i]])
				{
					index = sep[i];
					cout<<"\nElement found at position = "<<index+1<<endl;
					flag = 1;
					break;
				}
				if(ele<arr[sep[i]])
				{
					r = sep[i];
					if(i!=0)
					l = 1+sep[i-1];
					s = r-l+1;
					break;
				}
			}
			if(flag==1)
			break;
		}
	}
	if(l==r || !(ele>=arr[l] && ele<=arr[r]))
	{
		cout<<"\nElement not found"<<endl;
	}
	return 0;
}