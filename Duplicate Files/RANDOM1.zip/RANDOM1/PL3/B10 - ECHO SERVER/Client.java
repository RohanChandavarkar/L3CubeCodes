import java.io.*;
import java.net.*;

public class Client
{
	public static void main(String args[])
	{
		try
		{
			BufferedReader obj=new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Enter the server IP: ");
			String serverIP=obj.readLine();
			Socket sc=new Socket(serverIP, 1234);
			BufferedReader br=new BufferedReader(new InputStreamReader(sc.getInputStream()));
			PrintWriter out=new PrintWriter(new BufferedWriter(new OutputStreamWriter(sc.getOutputStream())),true);
			
			while(true)
			{
				System.out.print("Enter your message: ");
				String msg=obj.readLine();
				out.println(msg);
				System.out.print("Echo msg: "+br.readLine()+"\n");
			}
		}
		catch(Exception e)
		{
			System.out.println("Error-> "+e);
		}
	}
}
