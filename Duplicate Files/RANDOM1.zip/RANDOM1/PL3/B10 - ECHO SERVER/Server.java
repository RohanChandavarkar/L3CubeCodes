import java.io.*;
import java.net.*;
import java.lang.Thread.*;

public class Server
{
	public static int client_count=0;
	
	public static void main(String args[])
	{
		try
		{
			ServerSocket serversoc=new ServerSocket(1234);
			
			while(true)
			{
				client_count++;
				Socket soc=serversoc.accept();
				System.out.println("Client "+client_count+" connected to Echo Server");
				Runner r=new Runner(soc, client_count);
				r.start();
			}
		}
		catch(Exception e)
		{
			System.out.println("Error-> "+e);
		}
	}
}

class Runner extends Thread
{
	Socket soc;
	int id;
	public Runner(Socket s, int label)
	{
		this.soc=s;
		this.id=label;
	}
	
	public void run()
	{
		try
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(soc.getInputStream()));
			PrintWriter pr=new PrintWriter(soc.getOutputStream(), true);
			
			String msg="";
			while(true)
			{
				msg=br.readLine();
				System.out.print("Client "+id+" says: "+msg+"\n");
				pr.println(msg);
			}
		}
		catch(Exception e)
		{
			System.out.println("Error-> "+e);
		}
		finally
		{
			try
			{
				soc.close();
			}
			catch(Exception e)
			{
				System.out.println("Error-> "+e);
			}
		}
	}
}
