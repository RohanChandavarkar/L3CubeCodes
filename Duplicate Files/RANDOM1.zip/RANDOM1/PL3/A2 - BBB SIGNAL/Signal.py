import Adafruit_BBIO.GPIO as GPIO
import time
GPIO.setup("P9_11",GPIO.OUT)
GPIO.setup("P9_12",GPIO.OUT)
GPIO.setup("P9_13",GPIO.OUT)
GPIO.setup("P9_14",GPIO.OUT)
GPIO.setup("P9_15",GPIO.OUT)
GPIO.setup("P9_16",GPIO.OUT)

while(True):
        GPIO.output("P9_11",GPIO.HIGH)
        GPIO.output("P9_16",GPIO.HIGH)
        time.sleep(5)
        GPIO.output("P9_16",GPIO.LOW)
        GPIO.output("P9_15",GPIO.HIGH)
        time.sleep(3)
        GPIO.output("P9_15",GPIO.LOW)
        GPIO.output("P9_14",GPIO.HIGH)
        GPIO.output("P9_11",GPIO.LOW)
        GPIO.output("P9_13",GPIO.HIGH)
        time.sleep(5)
        GPIO.output("P9_13",GPIO.LOW)
        GPIO.output("P9_12",GPIO.HIGH)
        time.sleep(3)
        GPIO.output("P9_14",GPIO.LOW)
        GPIO.output("P9_12",GPIO.LOW)




