import Adafruit_BBIO.GPIO as GPIO
import time

GPIO.setup("P8_12", GPIO.OUT)
GPIO.setup("P8_11", GPIO.IN)
GPIO.setup("P8_14", GPIO.OUT)
GPIO.setup("P8_13", GPIO.IN)
GPIO.setup("P8_16", GPIO.OUT)
GPIO.setup("P8_15", GPIO.IN)
con=0


while True:
        curr= GPIO.input("P8_11")
        curr1= GPIO.input("P8_13")
        curr2= GPIO.input("P8_15")

        if(curr==1):
                if con==3:
                        GPIO.output("P8_14",GPIO.HIGH)
                        time.sleep(1)
                        print  "We are on second floor"
                        GPIO.output("P8_14",GPIO.LOW)

                GPIO.output("P8_12",GPIO.HIGH)
                GPIO.output("P8_14",GPIO.LOW)
                GPIO.output("P8_16",GPIO.LOW)
                time.sleep(2)
                GPIO.output("P8_16",GPIO.LOW)

                print "We are on first floor"
                con=1
        elif(curr1==1):
                GPIO.output("P8_14",GPIO.HIGH)
                GPIO.output("P8_12",GPIO.LOW)
                GPIO.output("P8_16",GPIO.LOW)
                time.sleep(2)
                con=2
                print "We are on second floor"
                GPIO.output("P8_14",GPIO.LOW)
        elif(curr2==1):
                if con==1:
                        GPIO.output("P8_14",GPIO.HIGH)
                        time.sleep(1)
                        print  "We are on second floor"
                        GPIO.output("P8_14",GPIO.LOW)

                GPIO.output("P8_16",GPIO.HIGH)
                GPIO.output("P8_14",GPIO.LOW)


