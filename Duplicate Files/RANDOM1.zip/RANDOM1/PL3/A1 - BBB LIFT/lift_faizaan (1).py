import Adafruit_BBIO.GPIO as GPIO
from time import sleep

buttons = ["P8_13", "P8_12", "P8_11"]
leds = ["P9_13", "P9_12", "P9_11"]

def get_button_index():
        for x in buttons:
                if(GPIO.input(x)==1):
                        return buttons.index(x)
        return "-1"

def glow_led(index):
        for led in leds:
                GPIO.output(led, GPIO.LOW)
        GPIO.output(leds[index],GPIO.HIGH)


for b,l in zip(buttons,leds):
	GPIO.setup(b,GPIO.IN)
	GPIO.setup(l,GPIO.OUT)
	GPIO.output(l,GPIO.LOW)
# on first floor
GPIO.output(leds[0], GPIO.HIGH)

isMoving = False
destination_val = -1
current_val = 0
transition_time = 2

while True:
	if isMoving:
		print repr(destination_val),"<---",repr(current_val)
		# implement lift logic here
		if destination_val==-1:
			isMoving = False
			print "nowhere to go?"
			continue
		if destination_val==current_val:
			print "on same floor"
			isMoving = False
			continue
		# now check for descend
		if destination_val<current_val:
			while destination_val<current_val:
				# the current_val th led is glowing
				print "current_val:",current_val
				sleep (transition_time)
				current_val -= 1
				glow_led(current_val)
			current_val=destination_val
		elif destination_val>current_val:
			while destination_val>current_val:
				print current_val,"<=",destination_val
				print "current_val:", current_val
				print "destination_val:", destination_val,"\n"
				sleep(transition_time)
				current_val+=1
				glow_led(current_val)
			current_val=destination_val
		print "control"
		isMoving = False
				
	else:
		# poll for button press
		val = get_button_index()		
		if val != "-1":
			print "button pressed for index:",val
			destination_val = val
			isMoving = True
			sleep(1)

