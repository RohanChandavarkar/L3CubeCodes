import os

#300mhz
print "Current frequency: 300Mhz"
os.system("cpufreq-set -f 300Mhz")
print "\nRESULTS FOR FACTORIAL CODE = "
os.system("python fact.py 1000")
print "\nRESULTS FOR FIBONNACI CODE = "
os.system("python fibonnaci.py 10")
print "\nRESULTS FOR PRIME NUMBER CODE = "
os.system("python prime.py 37")
print "\n"

#600mhz
print "Current frequency: 600Mhz"
os.system("cpufreq-set -f 600Mhz")
print "\nRESULTS FOR FACTORIAL CODE = "
os.system("python fact.py 1000")
print "\nRESULTS FOR FIBONNACI CODE = "
os.system("python fibonnaci.py 10")
print "\nRESULTS FOR PRIME NUMBER CODE = "
os.system("python prime.py 37")
print "\n"

