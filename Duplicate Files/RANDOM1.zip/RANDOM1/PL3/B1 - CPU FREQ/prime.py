import os
import sys
import time

def prime(n):
        if n>1:
                for i in range(2,n):
                        if (n%i) == 0:
                                print(n," is not a prime number")
                                break
                else:
                        print(n," is a prime number")

        else:
                print(n," is not a prime number")


if len(sys.argv) > 1:
        start_time = time.time()
        prime(int(sys.argv[1]))
        print "Time taken: %s seconds" % (time.time() - start_time)
