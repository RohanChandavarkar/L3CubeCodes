#FACTORIAL CODE
import sys
import os
import time


def fact(n):
        ans = 1
        for i in range(1,n+1):
                ans *= i
        return ans

if len(sys.argv) > 1:
        start_time = time.time()
        fact(int(sys.argv[1]))
        print "Time taken: %s seconds" % (time.time() - start_time)


---------------------------------------------------------------------------
#FIBONNACI SERIES CODE
import os
import sys
import time

def fib(n):
        a,b = 1,1
        for i in range(n-1):
                a,b = b,a+b
        return a

if len(sys.argv) > 1:
        start_time = time.time()
        fib(int(sys.argv[1]))
        print "Time taken: %s seconds" % (time.time() - start_time)
		
---------------------------------------------------------------------------
#PRIME NUMBER CODE
import os
import sys
import time

def prime(n):
        if n>1:
                for i in range(2,n):
                        if (n%i) == 0:
                                print(n," is not a prime number")
                                break
                else:
                        print(n," is a prime number")

        else:
                print(n," is not a prime number")


if len(sys.argv) > 1:
        start_time = time.time()
        prime(int(sys.argv[1]))
        print "Time taken: %s seconds" % (time.time() - start_time)

---------------------------------------------------------------------------