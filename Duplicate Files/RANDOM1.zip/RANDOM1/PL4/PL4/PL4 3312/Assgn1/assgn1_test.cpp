#include <iostream>
#include <string>
#include <cstring>
#include <crafter.h>
#include <stdio.h>

/* Collapse namespaces */
using namespace std;
using namespace Crafter;

int counter_request=0;
int counter_response=0;
int counter_total=0;

void PacketHandler(Packet* sniff_packet, void* user) {
        RawLayer* raw_payload = sniff_packet->GetLayer<RawLayer>();

        if(raw_payload) {


                string payload = raw_payload->GetStringPayload();
		string line;
		stringstream ss(payload);
		char delim='\n';
		getline(ss,line,delim);
                string test1="HTTP/1.1";
		string test2="GET";
		string test3="POST";
		string test4="HTTP/1.0";
		if(strstr(line.c_str(),test1.c_str())||strstr(line.c_str(),test4.c_str()))
		{
			counter_total++;
                	cout << "[+] ---PACKET--- [+]" << endl;
			cout<<line<<endl;
			cout << "[#] With Properties: " << endl;
			cout<<"HTTP PACKET FOUND!!!"<<endl;
			if((strstr(line.c_str(),test2.c_str()))||(strstr(line.c_str(),test3.c_str())))
			{
				counter_request++;
				cout<<"REQUEST PACKET FOUND!!!"<<endl;
			}
			else
			{
				counter_response++;
				cout<<"RESPONSE PACKET FOUND!!!"<<endl;
			}
		}

        }
	
}


int main() {
        string iface = "p1p1";
        Sniffer sniff("tcp",iface,PacketHandler);
        sniff.Capture(50);
	cout<<"[#] Analysis: "<<endl;
	cout<<"Total http packets captured : "<<counter_total<<endl;
	cout<<"Total http request packets captured : "<<counter_request<<endl;
	cout<<"Total http response packets captured : "<<counter_response<<endl;
        return 0;
}
