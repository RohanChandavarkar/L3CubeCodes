import os
os.chdir("nmap-6.47")
os.system("./configure")
os.system("make")
os.system("make install")
