import socket
import sys
from select import select

HOST = '127.0.0.1'
PORT = 8018
BUF_SIZE = 1024

class Client():
    def __init__(self, host=HOST, port=PORT):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host, port))
        print "Connected! Type `Bye` to quit'"
        while 1:
            cmd, _, _ = select([self.sock], [], [], 1)
            if cmd:
                buf = self.sock.recv(BUF_SIZE)
                print buf
            cmd, _, _ = select([sys.stdin], [], [], 1)
            if cmd:
                s = sys.stdin.readline()
                self.sock.send(s)
                if s.find('Bye') == 0:
                    exit()

client = Client()
