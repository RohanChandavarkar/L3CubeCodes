/*
	Name:Shweta Shinde
	Roll No:3359
*/

#include <iostream>
#include <stdio.h>
#include <string.h>
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<unistd.h>

using namespace std;

class asg2
{
            string ip;
            int same;
            int diff;

public:
            void same_subnet();
            void diff_subnet();
            void analysis(int b);
};

int main()
{
            asg2 ob;
            int choice;
        cout<<"Subnet mask: 255.255.255.192"<<endl;
        cout<<"IP address range:"<<endl;
        cout<<"SUBNET A- 192.168.4.0 - 192.168.4.63"<<endl;
        cout<<"SUBNET B- 192.168.4.64 - 192.168.4.127"<<endl;
        cout<<"SUBNET C- 192.168.4.128 - 192.168.4.191"<<endl;
        cout<<"SUBNET D- 192.168.4.192 - 192.168.4.255"<<endl;
            do{
                        cout<<"1.Ping the machine of same subnet"<<endl;
                        cout<<"2.Ping the machine of different subnet"<<endl;
			cout<<"3.Exit"<<endl;
                        cout<<"Enter choice:";
                        cin>>choice;
                        switch(choice)
                        {
                                    case 1: ob.same_subnet();
                                                break;
                                    case 2: ob.diff_subnet();
                                                break;
				    case 3: return 0;
                        }
            }while(choice!=4);
            return 0;
}

void asg2::same_subnet()
{         
            string cmd;
            cout<<"Enter IP address to PING: ";
            cin>>ip;
            cmd="ping "+ip;
            system(cmd.c_str());
            same=system(cmd.c_str());
            analysis(same);

}

void asg2::diff_subnet()
{
            string cmd;
            cout<<"Enter IP address to PING:";
            cin>>ip;
            cmd="ping "+ip;
            system(cmd.c_str());
            diff=system(cmd.c_str());
            analysis(diff);
}

void asg2::analysis(int res)
{
            if(res==0)
            {
                        cout<<"Successful PING. Machine is in same subnet"<<endl;
                cout<<"IP address: "<<ip<<endl;

            }
            else if(res==256)
            {
                        cout<<"Machine in the same subnet is shutdown"<<endl;
                cout<<"IP address: "<<ip<<endl;

            }

            else if(res==512)
            {
                        cout<<"Machine is in another subnet"<<endl;
                cout<<"IP address: "<<ip<<endl;
            }


}                     
