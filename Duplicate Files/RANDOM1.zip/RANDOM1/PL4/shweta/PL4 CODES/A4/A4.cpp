/*
Sujata Shinde
3360
*/

#include<iostream>
#include<stdlib.h>
using namespace std;
class DHCP
{
int failure;
public:
DHCP();
void configure();
void install();
void remove();
};
DHCP::DHCP()
{
failure=0;
}
void DHCP::configure()
{
system("yum install dhcp");
//system("vi /etc/dhcp/dhcpd.conf");
system("systemctl start dhcpd.service");
system("systemctl enable dhcpd.service");
system("chkconfig dhcpd on");
failure=system("service dhcpd restart");
if(failure==0)
{
cout<<"DHCP Server Started Successfully!!!";
}
else
{
cout<<"DHCP Server Failed";
}
}
void DHCP::install()
{
system("ssh 192.168.9.15 yum install sl");
//system("yum install sl");
}
void DHCP::remove()
{
system("ssh -l TE3 192.168.9.15");
system("yum remove sl");
}
int main()
{
DHCP d1;
int ch;
cout<<"\n\n1.Configure DHCP Server\n2.Remote Installation\n3.Remove\n\n Enter Your Choice::";
cin>>ch;
if(ch==1)
	d1.configure();
else if(ch==2)
	d1.install();
else if(ch==3)
	d1.remove();
}


/*Output:

[root@localhost A4]# ./a.out


1.Configure DHCP Server
2.Remote Installation
3.Remove

 Enter Your Choice::1
Loaded plugins: langpacks, refresh-packagekit
Package 12:dhcp-4.2.7-2.fc20.x86_64 already installed and latest version
Nothing to do
Note: Forwarding request to 'systemctl enable dhcpd.service'.
Redirecting to /bin/systemctl restart  dhcpd.service
DHCP Server Started Successfully!!!

[root@localhost A4]# ./a.out


1.Configure DHCP Server
2.Remote Installation
3.Remove

 Enter Your Choice::2

[root@localhost A4]# ./a.out


1.Configure DHCP Server
2.Remote Installation
3.Remove

 Enter Your Choice::3

*/
