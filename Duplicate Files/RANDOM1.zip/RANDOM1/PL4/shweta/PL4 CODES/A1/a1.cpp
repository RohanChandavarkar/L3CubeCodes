 #include <iostream>
#include <string>
#include <crafter.h>
#include<string>
#include<cstring>
using namespace std;
using namespace Crafter;
int tcp_count=0;
int http_count=0;
int req=0;
int res=0;
void PacketHandler(Packet* sniff_packet, void* user)
{

     
        RawLayer* raw_payload = sniff_packet->GetLayer<RawLayer>();
        if(raw_payload)
{
              
        TCP* tcp_layer = sniff_packet->GetLayer<TCP>();
        cout << "[#] TCP packet from source port: " << tcp_layer->GetSrcPort() << endl;
        tcp_count++;
        cout << "[#] With Payload: " << endl;
      
        string payload = raw_payload->GetStringPayload();
        string test1="HTTP/1.1";
        string test2="HTTP/1.0";
	string test3="GET";
	string test4="POST";
     
     	if(strstr(payload.c_str(),test1.c_str())||strstr(payload.c_str(),test2.c_str()))
	{
  	       cout<<"---------PACKET-------------"<<endl;
		 cout << payload << endl;
		cout<<"HTTP PACKET FOUND!!"<<endl;
		http_count++;
		if(strstr(payload.c_str(),test3.c_str())||strstr(payload.c_str(),test4.c_str()))
		{
                cout<<"REQUEST PACKET FOUND!"<<endl;
		req++;
		}
		else
		{
		cout<<"RESPONSE PACKET FOUND!"<<endl;
		res++;
		}
 	      
	}
        }
}
int main()
{
       
        string iface = "p4p1";
        
       Sniffer sniff("tcp",iface,PacketHandler);   
       sleep(5);
        sniff.Capture(5);
cout<<"\n Number of TCP packets are"<<tcp_count<<endl;
cout<<"\n Number of HTTP packets are"<<http_count<<endl;
cout<<"\n Number of Request packets are"<<req<<endl;
cout<<"\n Number of Response packets are"<<res<<endl;
       
        return 0;
}
