 #include <iostream>
#include <crafter.h>
using namespace std;
using namespace Crafter;
int main()
{
        string iface = "p4p1";
        string MyIP = GetMyIP(iface);
        cout << " My IP address is  : " << MyIP  << endl;
        IP ip_header;
	string DesIP;
	cout<<"Enter Destination IP Address:"<<endl;
	cin>>DesIP;
        ip_header.SetSourceIP(MyIP);
        ip_header.SetDestinationIP(DesIP);
        TCP tcp_header;
        tcp_header.SetSrcPort(11);
        tcp_header.SetDstPort(80);
        tcp_header.SetSeqNumber(RNG32());
        tcp_header.SetFlags(TCP::SYN);
        RawLayer payload("Hello!!!");
        Packet tcp_packet = ip_header / tcp_header / payload;
        cout << endl << "Before sending: " << endl;
        tcp_packet.Print();
        tcp_packet.Send();
        cout << endl << "After sending: " << endl;
        tcp_packet.Print();
        return 0;
}

