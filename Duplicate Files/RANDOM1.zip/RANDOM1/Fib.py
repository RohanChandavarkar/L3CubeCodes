import os
import sys
import time

def fib(n):
	a,b=1,1
	for i in range(n-1):
		a,b = b,a+b
	return a

if len(sys.argv) > 1:
	start = time.time()
	fib(int(sys.argv[1]))
	print "TIME = %s SECONDS" % (time.time()-start)