import os

print "CPU FREQ IS 300 MHZ"
os.system("cpufreq-set -f 300Mhz")
print "FACT"
os.system("python Fact.py 1000")
print "FIBONNACI"
os.system("python Fib.py 10")
print "PRIME"
os.system("python Prime.py 37")
print "\n"

print "CPU FREQ IS 600 MHZ"
os.system("cpufreq-set -f 600Mhz")
print "FACT"
os.system("python Fact.py 1000")
print "FIBONNACI"
os.system("python Fib.py 10")
print "PRIME"
os.system("python Prime.py 37")
print "\n"