#include<stdio.h>
#include<stdlib.h>
#include<CL/cl.h>
#define DATA_SIZE 10

const char *ProgramSource = 
"__kernel void vectorAdd(__global float *inputA,__global float *inputB,__global float *output)\n"\
"{\n"\
"	size_t id = get_global_id(0);\n"\
"	output[id] = inputA[id] + inputB[id];\n"\
"}\n";

int main(void)
{
cl_platform_id platform_id;
cl_uint num_of_platforms = 0;
cl_device_id device_id;
cl_uint num_of_devices = 0;
cl_int err;
cl_context context;
cl_context_properties properties[3];
cl_command_queue command_queue;
cl_kernel kernel;
cl_program program;
cl_mem inputA,inputB,output;
size_t global;
int i;

float inputDataA[DATA_SIZE] = {1,2,3,4,5,6,7,8,9,10};
float inputDataB[DATA_SIZE] = {1,2,3,4,5,6,7,8,9,10};
float result[DATA_SIZE] = {0};

if(clGetPlatFormIDs(1,&platform_id,&num_of_platforms)!=CL_SUCCESS)
{
	printf("\nUnable to get platform id");
	return 1;
}

if(clGetDeviceIDs(platform_id,CL_DEVICE_TYPE_ALL,1,&device_id,&num_of_devices)!=CL_SUCCESS)
{
	printf("\nUnable to get device id");
	return 1;
}

properties[0] = CL_CONTEXT_PLATFORM;
properties[1] = (cl_context_properties) platform_id;
properties[2] = 0; 

context = clCreateContext(properties,1,&device_id,NULL,NULL,&err);

command_queue = clCreateCommandQueue(context,device_id,0,&err);

program = clCreateProgramWithSource(context,1,(const char **) &ProgramSource,NULL,&err);

if(clBuildProgram(program,0,NULL,NULL,NULL,NULL)!=CL_SUCCESS)
{
	printf("\nUnable to build program");
	return 1;
}

kernel = clCreateKernel(program,"vectorAdd",&err);

inputA = clCreateBuffer(context,CL_MEM_READ_ONLY,sizeof(float) * DATA_SIZE,NULL,NULL);
inputB = clCreateBuffer(context,CL_MEM_READ_ONLY,sizeof(float) * DATA_SIZE,NULL,NULL);
output = clCreateBuffer(context,CL_MEM_WRITE_ONLY,sizeof(float) * DATA_SIZE,NULL,NULL);

clEnqueueWriteBuffer(command_queue,inputA,CL_TRUE,0,sizeof(float) * DATA_SIZE,inputDataA,0,NULL,NULL);
clEnqueueWriteBuffer(command_queue,inputB,CL_TRUE,0,sizeof(float) * DATA_SIZE,inputDataB,0,NULL,NULL);

clSetKernelArg(kernel,0,sizeof(cl_mem),&inputA);
clSetKernelArg(kernel,1,sizeof(cl_mem),&inputB);
clSetKernelArg(kernel,2,sizeof(cl_mem),&output);
global = DATA_SIZE;

clEnqueueNDRangeKernel(command_queue,kernel,1,NULL,&global,NULL,0,NULL,NULL);
clFinish(command_queue);

clEnqueueReadBuffer(command_queue,output,CL_TRUE,0,sizeof(float) * DATA_SIZE,result,0,NULL,NULL);

printf("\nOUTPUT = \n");

for(i=0;i<DATA_SIZE;i++)
{
	printf("%f \n",result[i]);
}

clReleaseMemObject(inputA);
clReleaseMemObject(inputB);
clReleaseMemObject(output);
clReleaseProgram(program);
clReleaseKernel(kernel);
clReleaseCommandQueue(command_queue);
clReleaseContext(context);

return 0;

}
