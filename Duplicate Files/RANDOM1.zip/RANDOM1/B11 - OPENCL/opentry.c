#include <CL/cl.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX_SOURCE_SIZE (0x100000)

int main(void) {
FILE *fp;
    char *source_str;
    size_t source_size;
    int i;
#pragma OPENCL EXTENSION cl_amd_printf:enable
    fp = fopen("kernel_file.cl", "r");
    if (!fp) {
        fprintf(stderr, "Failed to load kernel.\n");
        exit(1);
    }
    source_str = (char*)malloc(MAX_SOURCE_SIZE);
    source_size = fread( source_str, 1, MAX_SOURCE_SIZE, fp);
    fclose( fp );
	char *info;
    cl_uint infoSize;
    cl_platform_id platform_id = NULL;
    cl_device_id device_id = NULL;   
    cl_uint ret_num_devices;
    cl_uint ret_num_platforms;
    cl_int ret = clGetPlatformIDs(1, &platform_id, &ret_num_platforms);
    clGetPlatformInfo(platform_id,CL_PLATFORM_NAME,0, NULL, &infoSize);
    info=(char *)malloc(sizeof(char)*infoSize);
    clGetPlatformInfo(platform_id,CL_PLATFORM_NAME,infoSize, info, NULL);
    ret = clGetDeviceIDs( platform_id, CL_DEVICE_TYPE_ALL, 1, 
            &device_id, &ret_num_devices);
    
    cl_context context = clCreateContext( NULL, 1, &device_id, NULL, NULL, &ret);

    // Create a command queue
    cl_command_queue command_queue = clCreateCommandQueue(context, device_id, 0, &ret);

    // Create memory buffers on the device for each vector 
    
       cl_mem c_mem_obj = clCreateBuffer(context, CL_MEM_READ_ONLY , sizeof(int)*5, NULL, &ret);
      int *C = (int *)malloc(sizeof(int)*5);
    for(i=0;i<5;i++)
    {
       C[i]=0;
    }

      clEnqueueWriteBuffer(command_queue, c_mem_obj, CL_TRUE, 0,
                                 sizeof(int)*5 , C, 0, NULL, NULL);

    cl_program program = clCreateProgramWithSource(context, 1, 
            (const char **)&source_str, (const size_t *)&source_size, &ret);

    // Build the program
    ret = clBuildProgram(program, 1, &device_id, NULL, NULL, NULL);

    // Create the OpenCL kernel
    cl_kernel kernel = clCreateKernel(program, "simple_hello", &ret);
 
    ret = clSetKernelArg(kernel, 0, sizeof(cl_mem), (void *)&c_mem_obj);

    // Execute the OpenCL kernel on the list
    size_t global_item_size = 5; // Process the entire lists
    size_t local_item_size = 5; // Process in groups of 64
    ret = clEnqueueNDRangeKernel(command_queue, kernel, 1, NULL, &global_item_size, &local_item_size, 0, NULL, NULL);
    printf("Return code is %d\n",ret);
    
}
