import java.io.*;
import java.net.*;
import java.lang.Thread;

public class Server
{
	public static int clientcount = 0;
	public static void main(String args[])
	{
		try
		{
			ServerSocket serversoc = new ServerSocket(1234);
			while(true)
			{
				Socket soc = serversoc.accept();
				clientcount++;
				System.out.println("Client "+clientcount+" connected to Echo Server");
				Runner r = new Runner(soc,clientcount);
				r.start();
			}
		}
		catch(Exception e)
		{
			System.out.println("ERROR = "+e);
		}
	}
}

class Runner extends Thread
{
	Socket soc;
	int id;
	public Runner(Socket s,int label)
	{
		this.soc = s;
		this.id = label;
	}
	public void run
	{
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
			PrintWriter pr = new PrintWriter(soc.getOutputStream(),true);
			String msg = "";
			while(true)
			{
				msg = br.readLine();
				System.out.print("Client "+id+" says : "+msg+"\n");
				pr.println(msg);
			}
		}
		catch(Exception e)
		{
			System.out.println("ERROR = "+e);
		}
		finally
		{
			try
			{
				soc.close();
			}
			catch(Exception e)
			{
				System.out.println("ERROR = "+e);
			}
		}
	}
}