import os
import sys
import time

def prime(n):
	if n>1:
		for i in range(2,n):
			if (n%i) == 0:
				print "PRIME"
				break
			else:
				print "NO PRIME"
	else:
		print "NO PRIME"

if len(sys.argv) > 1:
	start = time.time()
	prime(int(sys.argv[1]))
	print "TIME = %s SECONDS" % (time.time()-start)